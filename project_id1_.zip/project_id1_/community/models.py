from django.db import models
from django.utils import timezone
# import datetime
# Create your models here.
class User(models.Model):
	full_name = models.CharField(max_length=200)
	nickname = models.CharField(max_length=100, help_text='your @ handle')
	bio = models.TextField()
	join_date = models.DateTimeField(auto_now_add=True,editable=False)

	def __str__(self):
		return self.nickname

class Post(models.Model):
	author = models.ForeignKey(User,verbose_name='Auteur', on_delete=models.CASCADE)
	title = models.CharField(verbose_name='Titre', max_length=200)
	description = models.TextField(max_length=300)
	content = models.TextField()
	picture = models.FileField(upload_to='images/', blank=True)
	published_date = models.DateTimeField(verbose_name='Date de publication', auto_now_add=timezone.now())

# default=datetime.date.today()
	def __str__(self):
		return self.title