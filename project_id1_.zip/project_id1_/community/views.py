from django.shortcuts import render, get_object_or_404
from .models import Post
from django.views.generic import ListView
from django.utils import timezone
# Create your views here.

def index(request):
	posts = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
	return render(request, 'community/index.html', {'posts':posts})

def more(request, pk):
	post = get_object_or_404(Post, pk=pk)
	return render(request, 'community/more.html', {'post':post})
